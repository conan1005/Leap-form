import React from 'react';

const FormSubmittedPage = () => {
  return (
    <div style={{ textAlign: 'center', marginTop: '50px' }}>
      <h1>That's all we need.</h1>
      <p>Thank you for your time. We will get back soon</p>
    </div>
  );
};

export default FormSubmittedPage;
